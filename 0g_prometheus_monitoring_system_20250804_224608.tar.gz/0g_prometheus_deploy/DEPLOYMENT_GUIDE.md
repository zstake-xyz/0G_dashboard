# 0G Galileo Prometheus 모니터링 시스템 배포 가이드

## 📋 개요

이 가이드는 0G Galileo 블록체인 벨리데이터를 위한 완전한 Prometheus 모니터링 시스템을 배포하는 방법을 설명합니다.

### 🎯 주요 기능

- **실시간 벨리데이터 모니터링**: 블록 서명, 놓친 블록, 벨리데이터 상태 추적
- **CometBFT 메트릭**: `cometbft_consensus_validator_missed_blocks` 포함
- **통합 메트릭 수집**: Node Exporter, 0G Node, 커스텀 메트릭 통합
- **Grafana 대시보드**: 실시간 시각화 및 알림
- **Nginx 리버스 프록시**: 안전한 웹 접근

## 🚀 시스템 요구사항

### 하드웨어
- **CPU**: 최소 2코어, 권장 4코어
- **RAM**: 최소 4GB, 권장 8GB
- **Storage**: 최소 20GB, 권장 50GB
- **Network**: 안정적인 인터넷 연결

### 소프트웨어
- **OS**: Ubuntu 20.04+ 또는 CentOS 8+
- **Docker**: 20.10+
- **Docker Compose**: 2.0+
- **Git**: 최신 버전

## 📦 설치 및 배포

### 1. 시스템 준비

```bash
# 시스템 업데이트
sudo apt update && sudo apt upgrade -y

# 필수 패키지 설치
sudo apt install -y curl wget git jq

# Docker 설치 (Ubuntu)
curl -fsSL https://get.docker.com -o get-docker.sh
sudo sh get-docker.sh
sudo usermod -aG docker $USER

# Docker Compose 설치
sudo curl -L "https://github.com/docker/compose/releases/latest/download/docker-compose-$(uname -s)-$(uname -m)" -o /usr/local/bin/docker-compose
sudo chmod +x /usr/local/bin/docker-compose

# 시스템 재시작 또는 새 세션 시작
newgrp docker
```

### 2. 프로젝트 다운로드

```bash
# 프로젝트 디렉토리 생성
mkdir -p ~/0g_prometheus
cd ~/0g_prometheus

# 프로젝트 파일 복사 (백업에서)
cp -r ../0g_prometheus_backup_20250723_183915/* .
```

### 3. 환경 설정

#### 3.1 RPC 엔드포인트 설정

`docker-compose.yml` 파일에서 RPC 엔드포인트를 실제 0G Galileo 노드 주소로 변경:

```yaml
environment:
  - RPC_ENDPOINT=http://YOUR_0G_NODE_IP:26657
  - NODE_EXPORTER_URL=http://YOUR_0G_NODE_IP:9100
```

#### 3.2 벨리데이터 주소 설정

`unified-metrics/main.go` 파일에서 추적할 벨리데이터 주소를 설정:

```go
validators := map[string]string{
    "YOUR_VALIDATOR_ADDRESS": "validator1",
    // 추가 벨리데이터...
}
```

### 4. 시스템 배포

```bash
# 컨테이너 빌드 및 시작
docker-compose build
docker-compose up -d

# 상태 확인
docker-compose ps
```

### 5. 포트 충돌 해결

만약 Prometheus 포트(9090)가 이미 사용 중인 경우:

```bash
# 포트 사용 확인
lsof -i :9090

# 기존 프로세스 종료
sudo kill -9 <PID>

# 컨테이너 재시작
docker-compose restart prometheus
```

## 🔧 설정 파일 설명

### docker-compose.yml
- **unified-metrics**: 커스텀 메트릭 수집기
- **prometheus**: 메트릭 저장 및 쿼리 엔진
- **grafana**: 시각화 대시보드
- **nginx**: 리버스 프록시

### prometheus.yml
- 단일 job `og-galileo-unified`로 통합된 메트릭 수집
- `/all-metrics` 엔드포인트에서 모든 메트릭 수집

### unified-metrics/main.go
- CometBFT 메트릭 포함
- 실시간 블록 서명 추적
- 벨리데이터 상태 모니터링

## 📊 메트릭 설명

### 주요 메트릭

| 메트릭 이름 | 설명 | 타입 |
|------------|------|------|
| `cometbft_consensus_validator_missed_blocks` | 벨리데이터가 놓친 블록 수 | Gauge |
| `og_galileo_validator_block_height` | 현재 블록 높이 | Gauge |
| `og_galileo_validator_is_bonded` | 벨리데이터 본딩 상태 | Gauge |
| `og_galileo_validator_is_jailed` | 벨리데이터 감금 상태 | Gauge |
| `og_galileo_validator_tokens` | 스테이킹된 토큰 수량 | Gauge |

### 라벨
- `validator`: 벨리데이터 식별자
- `chain_id`: 체인 ID ("0g-galileo")
- `instance`: 메트릭 소스 인스턴스
- `job`: 수집 작업 이름

## 🌐 접근 방법

### 웹 인터페이스
- **Prometheus**: http://YOUR_SERVER_IP:9090
- **Grafana**: http://YOUR_SERVER_IP:3000
- **Nginx (통합)**: http://YOUR_SERVER_IP

### API 엔드포인트
- **통합 메트릭**: http://YOUR_SERVER_IP:8080/all-metrics
- **Prometheus API**: http://YOUR_SERVER_IP:9090/api/v1/

## 🔍 모니터링 및 유지보수

### 로그 확인

```bash
# 전체 로그
docker-compose logs

# 특정 서비스 로그
docker-compose logs prometheus
docker-compose logs unified-metrics
docker-compose logs grafana
```

### 메트릭 확인

```bash
# 메트릭 엔드포인트 확인
curl http://localhost:8080/all-metrics

# Prometheus 쿼리
curl "http://localhost:9090/api/v1/query?query=cometbft_consensus_validator_missed_blocks"
```

### 컨테이너 관리

```bash
# 서비스 재시작
docker-compose restart

# 특정 서비스 재시작
docker-compose restart prometheus

# 서비스 중지
docker-compose down

# 서비스 시작
docker-compose up -d
```

## 🚨 문제 해결

### 일반적인 문제

1. **Prometheus 포트 충돌**
   ```bash
   lsof -i :9090
   sudo kill -9 <PID>
   docker-compose restart prometheus
   ```

2. **메트릭 수집 실패**
   ```bash
   # RPC 연결 확인
   curl http://YOUR_0G_NODE_IP:26657/status
   
   # unified-metrics 로그 확인
   docker-compose logs unified-metrics
   ```

3. **Grafana 접근 불가**
   ```bash
   # 기본 계정: admin/admin
   # 포트 확인
   lsof -i :3000
   ```

### 로그 분석

```bash
# 실시간 로그 모니터링
docker-compose logs -f

# 특정 키워드 검색
docker-compose logs | grep "ERROR"
docker-compose logs | grep "missed_blocks"
```

## 📈 성능 최적화

### 리소스 제한 설정

`docker-compose.yml`에 리소스 제한 추가:

```yaml
services:
  prometheus:
    deploy:
      resources:
        limits:
          memory: 2G
          cpus: '1.0'
```

### 데이터 보존 설정

`prometheus.yml`에서 데이터 보존 기간 설정:

```yaml
global:
  scrape_interval: 15s
  evaluation_interval: 15s
  external_labels:
    monitor: '0g-galileo-monitor'
```

## 🔒 보안 고려사항

### 방화벽 설정

```bash
# 필요한 포트만 열기
sudo ufw allow 80/tcp    # Nginx
sudo ufw allow 3000/tcp  # Grafana
sudo ufw allow 9090/tcp  # Prometheus
sudo ufw enable
```

### 인증 설정

Grafana에서 사용자 인증 설정:
1. Grafana 웹 인터페이스 접속
2. Admin > Users에서 새 사용자 생성
3. Admin > Authentication에서 LDAP 또는 OAuth 설정

## 📝 백업 및 복구

### 백업 생성

```bash
# 전체 시스템 백업
tar -czf 0g_prometheus_backup_$(date +%Y%m%d_%H%M%S).tar.gz \
  --exclude='./data' \
  --exclude='./logs' \
  .

# Prometheus 데이터 백업
docker run --rm -v 0g_prometheus_prometheus_data:/data \
  -v $(pwd):/backup alpine tar czf /backup/prometheus_data_backup.tar.gz -C /data .
```

### 복구

```bash
# 백업에서 복구
tar -xzf 0g_prometheus_backup_YYYYMMDD_HHMMSS.tar.gz

# Prometheus 데이터 복구
docker run --rm -v 0g_prometheus_prometheus_data:/data \
  -v $(pwd):/backup alpine tar xzf /backup/prometheus_data_backup.tar.gz -C /data
```

## 🔄 업데이트 가이드

### 코드 업데이트

```bash
# 현재 상태 백업
cp -r . ../0g_prometheus_backup_$(date +%Y%m%d_%H%M%S)

# 새 코드 적용
# (새로운 파일로 교체)

# 컨테이너 재빌드
docker-compose build
docker-compose up -d
```

### 설정 변경

```bash
# 설정 파일 수정 후
docker-compose restart prometheus
docker-compose restart unified-metrics
```

## 📞 지원 및 연락처

### 문제 보고
- GitHub Issues: [프로젝트 저장소]
- 이메일: [지원 이메일]

### 문서
- [Prometheus 공식 문서](https://prometheus.io/docs/)
- [Grafana 공식 문서](https://grafana.com/docs/)
- [0G Galileo 문서](https://docs.0g.ai/)

---

**버전**: v1.0.5  
**최종 업데이트**: 2025-07-23  
**작성자**: AI Assistant  
**라이선스**: MIT 