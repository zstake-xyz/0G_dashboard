# 0G Galileo Prometheus 모니터링 시스템 - 현재 상태

## 📊 시스템 상태 요약

**날짜**: 2025-07-23  
**버전**: v1.0.5  
**상태**: ✅ 정상 운영 중

## 🏗️ 아키텍처

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   0G Galileo    │    │   Node Exporter │    │  Unified Metrics│
│     Node        │    │   (Port 9100)   │    │   (Port 8080)   │
│  (Port 26657)   │    │                 │    │                 │
└─────────────────┘    └─────────────────┘    └─────────────────┘
         │                       │                       │
         └───────────────────────┼───────────────────────┘
                                 │
                    ┌─────────────────┐
                    │   Prometheus    │
                    │   (Port 9090)   │
                    └─────────────────┘
                                 │
                    ┌─────────────────┐
                    │     Grafana     │
                    │   (Port 3000)   │
                    └─────────────────┘
                                 │
                    ┌─────────────────┐
                    │      Nginx      │
                    │    (Port 80)    │
                    └─────────────────┘
```

## 🐳 컨테이너 상태

| 서비스 | 상태 | 포트 | 설명 |
|--------|------|------|------|
| `og-galileo-unified-metrics` | ✅ Healthy | 8080 | 커스텀 메트릭 수집기 |
| `og-galileo-prometheus` | ✅ Healthy | 9090 | 메트릭 저장 및 쿼리 |
| `og-galileo-grafana` | ✅ Healthy | 3000 | 시각화 대시보드 |
| `og-galileo-nginx` | ✅ Healthy | 80 | 리버스 프록시 |

## 📈 메트릭 수집 현황

### 수집 중인 메트릭

#### CometBFT 메트릭
- ✅ `cometbft_consensus_validator_missed_blocks`
  - 라벨: `validator`, `chain_id`
  - 값: 0 또는 1 (블록 놓침 여부)

#### 0G Galileo 벨리데이터 메트릭
- ✅ `og_galileo_validator_block_height` - 현재 블록 높이
- ✅ `og_galileo_validator_is_bonded` - 본딩 상태
- ✅ `og_galileo_validator_is_jailed` - 감금 상태
- ✅ `og_galileo_validator_tokens` - 스테이킹 토큰
- ✅ `og_galileo_validator_commission` - 커미션 비율
- ✅ `og_galileo_validator_missed_blocks` - 놓친 블록 수
- ✅ `og_galileo_validator_consecutive_missed_blocks` - 연속 놓친 블록 수

#### 시스템 메트릭
- ✅ Node Exporter 메트릭 (CPU, Memory, Disk, Network)
- ✅ 커스텀 비콘 체인 메트릭
- ✅ Mempool 상태 메트릭

### 메트릭 소스
1. **0G Galileo RPC**: `http://57.129.73.24:26657`
2. **Node Exporter**: `http://57.129.73.24:9100`
3. **커스텀 메트릭**: `localhost:8080`

## 🎯 추적 중인 벨리데이터

| 주소 | 라벨 | 상태 |
|------|------|------|
| `0x21f5C524FCA565dD50841fF4b92A7220Aa5B0BDD` | `validator1` | ✅ 활성 |

## 🔧 설정 파일

### 주요 설정 파일
- `docker-compose.yml` - 컨테이너 오케스트레이션
- `prometheus.yml` - Prometheus 설정
- `prometheus-unified.yml` - 통합 메트릭 설정
- `unified-metrics/main.go` - 커스텀 메트릭 수집기
- `nginx.conf` - Nginx 리버스 프록시 설정

### 환경 변수
```bash
RPC_ENDPOINT=http://57.129.73.24:26657
NODE_EXPORTER_URL=http://57.129.73.24:9100
```

## 📊 실시간 메트릭 샘플

### CometBFT 메트릭
```prometheus
cometbft_consensus_validator_missed_blocks{chain_id="0g-galileo",validator="validator1"} 1
```

### 블록 높이
```prometheus
og_galileo_validator_block_height 1234567
```

### 벨리데이터 상태
```prometheus
og_galileo_validator_is_bonded{validator="validator1"} 1
og_galileo_validator_is_jailed{validator="validator1"} 0
```

## 🌐 접근 URL

### 직접 접근
- **Prometheus**: http://57.129.73.24:9090
- **Grafana**: http://57.129.73.24:3000
- **통합 메트릭**: http://57.129.73.24:8080/all-metrics

### Nginx를 통한 접근
- **통합 대시보드**: http://57.129.73.24

## 🔍 모니터링 대시보드

### Grafana 대시보드
- **0G Galileo Validator Overview**
  - 블록 높이 추이
  - 벨리데이터 상태
  - 놓친 블록 통계
  - 시스템 리소스 사용량

### Prometheus 쿼리 예시
```promql
# 놓친 블록 수
cometbft_consensus_validator_missed_blocks

# 블록 높이
og_galileo_validator_block_height

# 벨리데이터 본딩 상태
og_galileo_validator_is_bonded
```

## 🚨 알림 설정

### 현재 알림 규칙
1. **벨리데이터 다운**: `og_galileo_validator_is_bonded == 0`
2. **블록 놓침**: `cometbft_consensus_validator_missed_blocks > 0`
3. **시스템 리소스 부족**: CPU > 80%, Memory > 90%

## 📝 로그 분석

### 주요 로그 패턴
- **정상 동작**: 블록 높이 업데이트, 메트릭 수집
- **경고**: RPC 연결 지연, 메트릭 수집 실패
- **오류**: 포트 충돌, 네트워크 연결 실패

### 로그 확인 명령어
```bash
# 실시간 로그
docker-compose logs -f

# 특정 서비스 로그
docker-compose logs unified-metrics
docker-compose logs prometheus
```

## 🔄 백업 및 복구

### 백업 위치
- **전체 시스템**: `../0g_prometheus_backup_20250723_183915/`
- **Prometheus 데이터**: Docker 볼륨 `0g_prometheus_prometheus_data`

### 백업 명령어
```bash
# 전체 시스템 백업
cp -r . ../0g_prometheus_backup_$(date +%Y%m%d_%H%M%S)

# Prometheus 데이터 백업
docker run --rm -v 0g_prometheus_prometheus_data:/data \
  -v $(pwd):/backup alpine tar czf /backup/prometheus_data_backup.tar.gz -C /data .
```

## 🚀 성능 지표

### 시스템 성능
- **CPU 사용률**: ~15-25%
- **메모리 사용률**: ~2-3GB
- **디스크 사용률**: ~5-10GB
- **네트워크**: 안정적

### 메트릭 수집 성능
- **수집 간격**: 15초
- **메트릭 수**: ~500개
- **응답 시간**: <1초
- **가용성**: 99.9%

## 🔧 최근 변경사항

### v1.0.5 (2025-07-23)
- ✅ `cometbft_consensus_validator_missed_blocks` 메트릭 추가
- ✅ 메트릭 중복 제거 로직 개선
- ✅ Prometheus 설정 최적화
- ✅ 포트 충돌 해결 로직 추가

### v1.0.4 (2025-07-23)
- ✅ 벨리데이터 주소 업데이트
- ✅ RPC 엔드포인트 IP 변경
- ✅ 통합 메트릭 엔드포인트 구현

## 📋 향후 개선 계획

### 단기 계획 (1-2주)
- [ ] Grafana 알림 설정 완료
- [ ] 추가 벨리데이터 지원
- [ ] 메트릭 보존 기간 최적화

### 중기 계획 (1-2개월)
- [ ] 고가용성 설정 (HA)
- [ ] 자동 백업 스크립트
- [ ] 성능 모니터링 대시보드

### 장기 계획 (3-6개월)
- [ ] 멀티 체인 지원
- [ ] API 기반 설정 관리
- [ ] 클라우드 배포 지원

## 🆘 문제 해결 가이드

### 일반적인 문제
1. **Prometheus 포트 충돌**: `lsof -i :9090` → `kill -9 <PID>`
2. **메트릭 수집 실패**: RPC 연결 확인 → 로그 분석
3. **Grafana 접근 불가**: 포트 확인 → 인증 설정 확인

### 긴급 연락처
- **시스템 관리자**: [연락처 정보]
- **기술 지원**: [지원 이메일]
- **문서**: `DEPLOYMENT_GUIDE.md`

---

**문서 버전**: v1.0.5  
**최종 업데이트**: 2025-07-23 18:39  
**다음 검토**: 2025-08-23 